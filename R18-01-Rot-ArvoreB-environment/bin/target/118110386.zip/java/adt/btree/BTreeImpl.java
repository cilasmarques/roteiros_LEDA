package adt.btree;

public class BTreeImpl<T extends Comparable<T>> implements BTree<T> {

	protected BNode<T> root;
	protected int order;

	public BTreeImpl(int order) {
		this.order = order;
		this.root = new BNode<T>(order);
	}

	@Override
	public BNode<T> getRoot() {
		return this.root;
	}

	@Override
	public boolean isEmpty() {
		return this.root.isEmpty();
	}

	@Override
	public int height() { return height(this.root); }

	private int height(BNode<T> node) {
		int result = -1;
		if (!node.isEmpty()) {
			if (node.isLeaf())
				return 0;
			else
				result = 1 + height(node.children.get(0));
		}
		return result;
	}

	@Override
	public BNode<T>[] depthLeftOrder() {
		BNode<T>[] array = new BNode[countNodes(getRoot())];
		depthLeftOrder(array, 0, this.root);
		return array;
	}

	private int depthLeftOrder(BNode<T> array[], int index, BNode<T> node) {
		if (!node.isEmpty() && node != null) {
			array[index] = node;
			index++;
			for (int i = 0; i < node.children.size(); i++) {
				index = depthLeftOrder(array, index, node.children.get(i));
			}
		}
		return index;
	}

	private int countNodes(BNode<T> node) {
		if (node.isEmpty()) return 0;
		int total = 1;

		for (int i = 0; i < node.children.size(); i++) {
			total += countNodes(node.children.get(i));
		}
		return total;
	}

	@Override
	public int size() {
		return size(getRoot());
	}

	private int size(BNode<T> node) {
		int result = 0;
		if (!node.isEmpty() && node != null) {
			if (node.isLeaf()) {
				result = node.size();
			} else {
				result = node.size();
				for (int i = 0; i < node.getChildren().size(); i++) {
					result += size(node.getChildren().get(i));
				}
			}
		}
		return result;
	}

	@Override
	public BNodePosition<T> search(T element) {
		if (element != null){
			return search(getRoot(), element);
		}
		return null;
	}

	private BNodePosition<T> search(BNode<T> node, T element) {
		int i = 1;
		while (i <= node.size() && element.compareTo(node.elements.get(i)) > 0 ) {i++;}
		if (i < node.size() && element.equals(node.elements.get(i)))
			return new BNodePosition<>(node,i);
		if (node.isLeaf())
			return new BNodePosition<>();

		return search(node.getChildren().get(i), element);
	}

	@Override
	public void insert(T element) {
		if (element != null)
			insert(element, getCorrectNode(getRoot(), element));
	}

	private void insert(T element, BNode<T> node) {
		if (node.isFull())
			split(node, element);
		else
			node.addElement(element);
	}

	private BNode<T> getCorrectNode(BNode<T> node, T element) {
		if (node.isEmpty() || node.isLeaf())
			return node;
		else {
			int i = 0;
			while (i < node.size() && element.compareTo(node.getElementAt(i)) > 0 ) {i++;}
			return getCorrectNode(node.getChildren().get(i), element);
		}
	}

	private void split(BNode<T> node, T element) {
		T promoteElement = node.getElementAt(node.size() / 2);
		BNode<T> parent = promote(node, promoteElement);
		BNode<T> leftChildren = new BNode<>(order);
		BNode<T> rightChildren = new BNode<>(order);
		node.addElement(element);

		for (int i = 0; i < node.size() / 2; i++){
			if (node.getElementAt(i) != null)
				leftChildren.addElement(node.getElementAt(i));
			//A herança de filhos esta dando errado
			//if (node.getChildren().get(i) != null)
				//leftChildren.addChild(j, node.getChildren().get(i));
		}

		for (int j = node.size() / 2; j < node.size(); j++){
			if (node.getElementAt(j) != null)
				rightChildren.addElement(node.getElementAt(j));
			//A herança de filhos esta dando errado
			//if (node.getChildren().get(j) != null)
				//rightChildren.addChild(j, node.getChildren().get(j));
		}

		int childIndex = 0;
		for (int k = 0; k < parent.size(); k++){
			if (parent.getElementAt(k).equals(promoteElement));
			childIndex = k;
		}

		parent.addChild(childIndex , leftChildren);
		parent.addChild(childIndex + 1, rightChildren);
		parent.removeChild(node);
	}

	private BNode<T> promote(BNode<T> node, T promoteElement) {
		if (node.getParent() == null){
			BNode newParent = new BNode(order);
			node.setParent(newParent);
			root = newParent;
		}

		if (node.getParent().isFull()) {
			split(node.getParent(), promoteElement);
		}

		node.getParent().addElement(promoteElement);
		node.removeElement(promoteElement);
		return node.getParent();
	}

	// NAO PRECISA IMPLEMENTAR OS METODOS ABAIXO
	@Override
	public BNode<T> maximum(BNode<T> node) {
		// NAO PRECISA IMPLEMENTAR
		throw new UnsupportedOperationException("Not Implemented yet!");
	}

	@Override
	public BNode<T> minimum(BNode<T> node) {
		// NAO PRECISA IMPLEMENTAR
		throw new UnsupportedOperationException("Not Implemented yet!");
	}

	@Override
	public void remove(T element) {
		// NAO PRECISA IMPLEMENTAR
		throw new UnsupportedOperationException("Not Implemented yet!");
	}

}
