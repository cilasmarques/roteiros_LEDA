package problems;


import org.junit.Test;

public class teste2 {

    FloorCeilBinarySearch teste2 = new FloorCeilBinarySearch();

    @Test
    public void teste1() {
        Integer[] inteiros = {0,1,2,3,4,5,6,7,8,9};
        Integer ceil = teste2.ceil(inteiros, 10);
        Integer floor = teste2.floor(inteiros, -1);
        System.out.println(ceil);
        System.out.println(floor);
    }

}
